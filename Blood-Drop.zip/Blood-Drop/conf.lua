function love.conf(t)
    t.title = "Blood Drop"         -- The title of the window (default "Untitled")
    t.window.width = 800             -- Window width (default 800)
    t.window.height = 600            -- Window height (default 600)
    t.window.resizable = false       -- Let the window be user-resizable (default false)
    t.window.vsync = 1               -- Vertical sync mode (default 1)
end
